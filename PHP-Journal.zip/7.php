<?php
$i = 1; 
while($i < 6) 
{
  echo "The Number is: $i<br>";
  $i++;
}
?>