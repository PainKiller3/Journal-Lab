<?php
if(isset($_GET['ch1']))
{
	echo $_GET ['ch1']. " is selected ";
}
if(isset($_GET['ch2']))
{
	echo $_GET ['ch2']. " is selected ";
}
if(isset($_GET['ch3']))
{
	echo $_GET ['ch3']. " is selected";
}
?>