<?php
$x=10;
$y=3;
echo "Addition=".($x+$y)."<BR>";
echo "Subtraction=".($x-$y)."<BR>";
echo "Multiplication=".($x*$y)."<BR>";
echo "Division=".($x/$y)."<BR>";
echo "Modulo=".($x%$y)."<BR>";
?>