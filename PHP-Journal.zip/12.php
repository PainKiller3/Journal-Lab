<?php
$opt=1;
switch ($opt) {
	case 1:
		echo "one";
		break;
	case 2:
		echo "two";
		break;
	case 3:
		echo "three";
		break;
	default:
		echo "Invalid Option";
		break;
}
?>