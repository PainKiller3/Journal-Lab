<?php
function writemsg($xyz="BLITZ")
{
echo "HEllo $xyz <br>";
}
writemsg();
writemsg("REIGNZ");
?>
