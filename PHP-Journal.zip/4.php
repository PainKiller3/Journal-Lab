<?php
$per=80;
if ($per>=90){
	echo "First Class";
	}
	elseif ($per>=75&& $per<=89){
	echo "Second Class";
	}
	elseif ($per>=40 &&$per<=74){
	echo "Pass";
	}
	else{
	echo "Fail";
	}
?>