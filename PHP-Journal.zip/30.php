<?php
echo $_GET['eno'];
$str=$_GET['fname'];
echo "<BR>";
echo $_GET['Gender'] . " is selected";
echo "<BR>";
echo $_GET['lang1']." language is selected";
echo "<br>";
echo $_GET['lang2']." language is selected";
echo "<br>";
echo $_GET['lang3']." language is selected";
echo "<br>";
echo $_GET['city'] . " is selected";
echo "<BR>";
?>