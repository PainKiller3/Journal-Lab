<?php
function add($x,$y)
{
$z=$x+$y;
return $z;
}
echo "sum: 156+183= ".add(156,183);
?>