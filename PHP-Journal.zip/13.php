<?php
function writemsg()
{
echo "HEllo REIGNZ";
}
writemsg();
?>