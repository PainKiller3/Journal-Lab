<?php
$n=$_GET['no'];
$x=$n;
if($x%2==0)
{
	echo $x. " is even";
}
else
{
	echo $x. " is odd";
}
?>