<?php
$i = 1; 
do
 {
    echo "The Number is: $i <br>";
    $i++;
} while($i < 6);
?>