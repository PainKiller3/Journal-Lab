<?php
echo $_GET ['city'] . " is selected";
?>