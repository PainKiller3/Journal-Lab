<?php
echo $_GET ['Gender'] . "is selected";
?>