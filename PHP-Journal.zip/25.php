<?php
$n1=$_GET['fno'];
$n2=$_GET['sno'];
if($n1>$n2)
{
	echo "$n1 is max";
}
else
{
	echo "$n2 is max";
}
?>