<?php
$n1=$_POST['fno'];
$n2=$_POST['sno'];
$a=$n1+$n2;
echo "Addition of $n1+$n2=$a";
?>