<?php
function writemsg($xyz)
{
echo "HEllo $xyz";
}
writemsg("REIGNZ");
?>
