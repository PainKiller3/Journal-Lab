<?php
$user="reignz";
setcookie($user,"",time()-3600);
echo "Cookie Deleted";
?>