<?php
$a = 50;
$b = 10;
if($a > $b)
 {
  echo "$a is Greater than $b";
}
?>