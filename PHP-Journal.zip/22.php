<?php
$str=$_GET['textm'];
echo "Welcome ".$str;
?>