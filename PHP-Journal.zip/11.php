<?php
$n=5;
echo "<table border=1 cellpadding=10>";
for($i=1;$i<=10;$i++)
{
	echo "<tr>";echo "<td>";
	echo $n*$i;echo "</td>";echo "</tr>";
}echo "</table>";
?>