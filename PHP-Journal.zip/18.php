<?php
$name=array("Reignz", "Hkr", "Blitz");
sort($name);
foreach($name as $x)
{
echo $x;
echo "<br>";
}
?>
