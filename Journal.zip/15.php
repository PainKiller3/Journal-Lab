<?php
function np($msg="Reignz")
{
echo "Welcome $msg <br>";
}
np();
np("Reignz/Blitz");
?>
