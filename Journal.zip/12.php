<?php
$option=3;
switch ($option) {
	case 1:
		echo "First";
		break;
	case 2:
		echo "Second";
		break;
	case 3:
		echo "Third";
		break;
	default:
		echo "Wrong Choice";
		break;
}
?>
