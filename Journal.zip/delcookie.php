<?php
$user="blitz";
setcookie($user,"",time()-3600);
echo "Cookie Deleted";
?>
