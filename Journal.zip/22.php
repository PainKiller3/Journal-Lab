<?php
$x=$_GET['txt'];
echo "Welcome ".$x;
?>
