<?php
$age=array("Mehul"=>"20", "Vishal"=>"25", "Arindam"=>"26");
foreach($age as $x=>$xval)
{
echo "Key=".$x.", Value=".$xval;
echo "<br>";
}
?>
