<?php
function ccat($fst,$sec)
{
return $fst." ".$sec;
}
echo ccat("Welcome", "Reignz");
?>
