<?php
function np($msg)
{
echo "Welcome $msg";
}
np("Reignz");
?>
