<?php
$a = TRUE;
if($a==TRUE)
{
  echo "Statement is TRUE";
}
else 
{
    echo "Statement is FALSE";
}
?>
