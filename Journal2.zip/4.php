<?php
$a=60;
$b=60;
if ($a>$b)
{
	echo "$a is greater";
}
else if($b>$a)
{
	echo "$b is greater";
}
else
{
	echo "$a is equal to $b";
}
?>
