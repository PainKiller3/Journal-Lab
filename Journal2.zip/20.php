<?php
$num=array(8,9,6,4,7,1,2);
rsort($num);
foreach($num as $x)
{
	echo $x."<br>";
}
?>
