<?php
$file1=fopen("test2.txt","a");
fwrite($file1,"Reignz");
fclose($file1);
?>
