<?php
function np()
{
echo "Welcome Reignz";
}
np();
?>
