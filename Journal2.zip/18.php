<?php
$nm=array('XsploIT','Arindam','Mehul','Nishant',
'Tejas','Raaj','Reignz');
sort($nm);
foreach($nm as $x)
{
echo $x;
echo "<br>";
}
?>
